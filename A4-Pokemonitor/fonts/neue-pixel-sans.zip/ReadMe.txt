The Neue Pixel Sans font free for Personal Use only.
You can use thise font free in your video for YouTube or Twitch and etc but not for commercial purposes.
If You want use this font for commerucal please write me to mail: morderdrakonovich@gmail.com send mail with marked "Trender Font"
or buy it on Creative Fabrica - https://www.creativefabrica.com/product/munistic/

Copyright � 2018 by Vasily Draigo aka Daymarius. All rights reserved.
